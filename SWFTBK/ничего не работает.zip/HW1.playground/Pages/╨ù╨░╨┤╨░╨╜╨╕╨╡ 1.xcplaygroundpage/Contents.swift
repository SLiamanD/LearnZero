// VasilievAG_HW1 i.kasyanenko@swiftbook.ru

//:  [Сылка на тесты]( https://docs.google.com/forms/d/e/1FAIpQLScW1PhBbiwigdcHwR8v1e9mro5N_kJIksb74E1fFqFSZ3Uw-g/viewform)

import UIKit

/*:
 ## Home Work 1
 
 ### Задание 1
 
 Объявите две строковые константы `firstString` и `secondString`. Присвойте им значения "I can" и "code" (именно такие, ни каких хитростей с лишними пробелами). Выведите в консоль фразу "I can code!" используя эти строковые переменные.
 */
let firstString:String
let secondString:String
firstString = "I can"
secondString = "code"
print(firstString + " " + secondString)

//: Задание 1 из 3  |  [Далее: Задание 2](@next)
